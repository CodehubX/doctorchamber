<?php
	$CI = get_instance();
	$CI->load->database();
	$CI->load->dbforge();


	// CREATE FILES 

	$fields = array(
		'file_id' =>array
		(
			'type' => 'INT',
			 'constraint' => 11,
			'auto_increment' => TRUE
		),

		'type' =>array
		(
			'type' => 'VARCHAR',
			'constraint' => '50',
			'null' => TRUE,
		),

		'patient_id' =>array
		(
			'type' => 'INT',
			'constraint' =>11,
			'null' => TRUE,
		),

		'prescription_id' =>array
		(
			'type' => 'INT',
			'constraint' =>11,
			'null' => TRUE,
		),

		'invoice_id' =>array
		(
			'type' => 'INT',
			'constraint' =>11,
			'null' => TRUE,
		),

		'file_name' =>array
		(
			'type' => 'LONGTEXT',
			'null' => TRUE,
		)
	);

	$CI->dbforge->add_field($fields);
	$CI->dbforge->add_key('file_id', TRUE);
	$attributes = array('CHARACTER SET' => 'utf8', 'COLLATE' => 'utf8_unicode_ci');
	$CI->dbforge->create_table('file', TRUE , $attributes);

	// ADD COLUMN IN USERS
	$fields = array(
		'qualification'=>array(
			'type'=>'VARCHAR',
			'constraint' =>'255',
			'null' => TRUE,
	)
	);
	
	$CI->dbforge->add_column('users',$fields);

?>