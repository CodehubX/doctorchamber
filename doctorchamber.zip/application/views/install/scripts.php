<script src="<?php echo base_url('assets/backend/bootstrap/dist/js/tether.min.js');?>"></script>

<script src="<?php echo base_url('assets/backend/bootstrap/dist/js/bootstrap.min.js');?>"></script>

<script src="<?php echo base_url('assets/backend/plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js');?>"></script>

<script src="<?php echo base_url('assets/backend/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js');?>"></script>

<script src="<?php echo base_url('assets/backend/js/jquery.slimscroll.js');?>"></script>

<script src="<?php echo base_url('assets/backend/js/waves.js');?>"></script>

<script src="<?php echo base_url('assets/backend/js/custom.min.js');?>"></script>
