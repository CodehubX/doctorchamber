<footer class="footer text-center">
	Need help?  <a href="#" target="_blank" style="text-decoration:underline;">Contact support</a>
</footer>
