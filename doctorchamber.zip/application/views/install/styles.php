<script src="<?php echo base_url('assets/backend/plugins/bower_components/jquery/dist/jquery.min.js');?>"></script>

<link href="<?php echo base_url('assets/backend/bootstrap/dist/css/bootstrap.min.css');?>"
      rel="stylesheet">

<link href="<?php echo base_url('assets/backend/plugins/bower_components/bootstrap-extension/css/bootstrap-extension.css');?>"
      rel="stylesheet">

<link href="<?php echo base_url('assets/backend/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css');?>"
      rel="stylesheet">

<link href="<?php echo base_url('assets/backend/css/animate.css');?>"
      rel="stylesheet">

<link href="<?php echo base_url('assets/backend/css/style.css');?>"
      rel="stylesheet">

<link href="<?php //echo base_url('assets/backend/css/custom.css');?>"
      rel="stylesheet">

<link href="<?php echo base_url('assets/backend/css/colors/theme.css');?>" id="theme"
      rel="stylesheet">

<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->

<!--[if lt IE 9]><script src="assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
  <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
