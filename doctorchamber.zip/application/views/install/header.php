<nav class="navbar navbar-default navbar-static-top m-b-0">
    <div class="navbar-header">
        <!-- Toggle icon for mobile view -->
        <a class="navbar-toggle hidden-sm hidden-md hidden-lg "
           href="javascript:void(0)" data-toggle="collapse"
           data-target=".navbar-collapse"><i class="ti-menu"></i></a>
        <!-- Logo -->
        <div class="top-left-part" style="width: 50%;">
            <a class="logo" href="<?php echo site_url('install');?>">
                <!-- Logo icon image, you can use font-icon also -->
                <b><img width="40" src="<?php echo base_url('uploads/logo.png');?>"></b>
                <span class="hidden-xs" style="font-size: 14px;">
                    Doctor Chamber Management System Installation
                </span>
            </a>
        </div>
        <!-- /Logo -->
    </div>
</nav>