<script src="<?php echo base_url('assets/backend/plugins/bower_components/jquery/dist/jquery.min.js');?>"></script>
<script src="<?php echo base_url('assets/backend/plugins/bower_components/calendar/jquery-ui.min.js');?>"></script>

<link href="<?php echo base_url('assets/backend/bootstrap/dist/css/bootstrap.min.css');?>"
      rel="stylesheet">

<link href="<?php echo base_url('assets/backend/plugins/bower_components/bootstrap-extension/css/bootstrap-extension.css');?>"
      rel="stylesheet">

<link href="<?php echo base_url('assets/backend/plugins/bower_components/bootstrap-select/bootstrap-select.min.css');?>"
      rel="stylesheet" />

<link href="<?php echo base_url('assets/backend/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css');?>"
      rel="stylesheet">

<link href="<?php echo base_url('assets/backend/plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.css');?>"
      rel="stylesheet" type="text/css" />

<link href="<?php echo base_url('assets/backend/plugins/bower_components/bootstrap-daterangepicker/daterangepicker.css');?>"
      rel="stylesheet">

<link href="<?php echo base_url('assets/backend/plugins/bower_components/custom-select/custom-select.css');?>"
      rel="stylesheet" type="text/css">

<link href="<?php echo base_url('assets/backend/plugins/bower_components/datatables/jquery.dataTables.min.css');?>"
      rel="stylesheet" type="text/css">

<link href="<?php echo base_url('assets/backend/plugins/bower_components/toast-master/css/jquery.toast.css');?>"
      rel="stylesheet">

<link href="<?php echo base_url('assets/backend/plugins/bower_components/sweetalert/sweetalert.css');?>"
      rel="stylesheet" type="text/css">

<link href="<?php echo base_url('assets/backend/plugins/bower_components/switchery/dist/switchery.min.css');?>"
      rel="stylesheet">

<link href="<?php echo base_url('assets/backend/plugins/bower_components/dropify/dist/css/dropify.min.css');?>"
      rel="stylesheet">

<link href="<?php echo base_url('assets/backend/plugins/bower_components/calendar/dist/fullcalendar.css');?>"
      rel="stylesheet" />

<link href="<?php echo base_url('assets/backend/css/animate.css');?>"
      rel="stylesheet">

<link href="<?php echo base_url('assets/backend/css/style.css');?>"
      rel="stylesheet">

<link href="<?php //echo base_url('assets/backend/css/custom.css');?>"
      rel="stylesheet">

<link href="<?php echo base_url('assets/backend/css/colors/theme.css');?>" id="theme"
      rel="stylesheet">

<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->