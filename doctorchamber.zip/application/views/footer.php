<footer class="footer text-center">
    2017 &copy; Doctor Chamber Management System V-1.1 by <strong>DBCINFOTECH</strong>
</footer>