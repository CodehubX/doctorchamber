Please read the following instructions properly for successfully updating the application.
1. Take a note of the database information that you are currently using for the application. You will need that later in the process.
2. Unzip the downloaded copy of the application that you have downloaded from codecanyon.
3. Replace all the files that you have on your server currently for the application with the newly unzipped files.
4. Go to database.php in application/config/database.php and put previously noted database information.
5. Go to routes.php in application/config/routes.php and change default controller form 'install' to 'login'.
6. Login to the application, go to settings and provide your purchase code and save.
7. After that in this page you will find a file uploaded section as update product. Upload the update1.1.zip file here and hit the update button.
8. Enjoy